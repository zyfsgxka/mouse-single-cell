library(Seurat)
library(ggplot2)
library(ggsci)

##################E14####################
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2 mouse\\E14 repeat")
E14_2.named<-readRDS('E14_2')
new.cluster.ids_3 <- c("other cells","other cells","other cells","PsC","other cells","other cells","other cells","other cells","other cells",
                       "other cells","other cells","HC","other cells")
names(new.cluster.ids_3) <- levels(E14_2.named)
E14_2.named <- RenameIdents(E14_2.named, new.cluster.ids_3)


table(Idents(E14_2.named))###Count the number of cells in each cluster
prop.table(table(Idents(E14_2.named)))###Calculating Cell Proportion
cell.prop_E14<-as.data.frame(prop.table(table(Idents(E14_2.named))))
#cell.prop_E14<-as.data.frame(table(Idents(E14)))
colnames(cell.prop_E14)<-c("cell_type","proportion")
cell.prop_E14$time<-"E_14"
signif(cell.prop_E14$proportion, 4)######Keep four decimals
ggplot(cell.prop_E14,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
    ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_d3()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.02), position=position_dodge(1), vjust=0)+xlab("E14")


##################E16####################
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2 mouse\\E16 repeat")

E16_cca<-readRDS("E16_cca")


new.cluster.ids_3 <- c("other cells","other cells","other cells","PsC","other cells","other cells","other cells",
                       "HC","other cells","other cells","other cells","other cells","other cells","SC",
                       "other cells","SC","SC","other cells",
                       "SC","SC")
names(new.cluster.ids_3) <- levels(E16_cca)
E16 <- RenameIdents(E16_cca, new.cluster.ids_3)
#
table(Idents(E16))
prop.table(table(Idents(E16)))
cell.prop_E16<-as.data.frame(prop.table(table(Idents(E16))))
#cell.prop_E16<-as.data.frame(table(Idents(E16)))
colnames(cell.prop_E16)<-c("cell_type","proportion")
cell.prop_E16$time<-"E_16"
signif(cell.prop_E16$proportion, 4)

#
ggplot(cell.prop_E16,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)

############### P1  #########
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2 mouse\\P1_repeat")
P1<-readRDS('P1.cca')

new.cluster.ids_3 <- c("other cells","other cells","other cells","other cells","other cells","other cells","other cells",
                       "other cells","other cells","HC","SC","other cells","SC",
                       "SC","other cells","other cells",
                       "other cells","other cells","other cells","HC","SC","other cells","other cells",
                       "other cells")
names(new.cluster.ids_3) <- levels(P1)
P1 <- RenameIdents(P1, new.cluster.ids_3)
#
table(Idents(P1))
prop.table(table(Idents(P1)))
cell.prop_P1<-as.data.frame(prop.table(table(Idents(P1))))
#cell.prop_P1<-as.data.frame(table(Idents(P1)))
colnames(cell.prop_P1)<-c("cell_type","proportion")
cell.prop_P1$time<-"P1"
signif(cell.prop_P1$proportion, 4)

ggplot(cell.prop_P1,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)

############ P7
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2 mouse\\P7_repeat")
P7_cca<-readRDS("P7_cca")
new.cluster.ids_3 <- c("other cells","other cells","other cells","other cells","other cells","other cells","SC","SC","SC",
                       "SC","HC","other cells","other cells","HC","other cells")
names(new.cluster.ids_3) <- levels(P7_cca)
P7 <- RenameIdents(P7_cca, new.cluster.ids_3)
#
table(Idents(P7))
#prop.table(table(Idents(P7)))
cell.prop_P7<-as.data.frame(prop.table(table(Idents(P7))))
#cell.prop_P7<-as.data.frame(table(Idents(P7)))
colnames(cell.prop_P7)<-c("cell_type","proportion")
cell.prop_P7$time<-"P7"
signif(cell.prop_P7$proportion, 4)

ggplot(cell.prop_P7,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)
      

############ P12
P12<-readRDS("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2 mouse\\P12\\P12.cca")
new.cluster.ids_2 <- c("other cells","SC","other cells","other cells","other cells","other cells","HC",
                       "HC","HC","SC","other cells","other cells")
names(new.cluster.ids_2) <- levels(P12)
P12 <- RenameIdents(P12, new.cluster.ids_2)
#
table(Idents(P12))
#prop.table(table(Idents(P12)))
cell.prop_P12<-as.data.frame(prop.table(table(Idents(P12))))
#cell.prop_P12<-as.data.frame(table(Idents(P12)))
colnames(cell.prop_P12)<-c("cell_type","proportion")
cell.prop_P12$time<-"P12"
signif(cell.prop_P12$proportion, 4)

ggplot(cell.prop_P12,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)


############ P33
P33<-readRDS("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2 mouse\\P33\\P33.object")

new.cluster.ids_2 <- c("other cells","HC","SC","SC","HC","SC","HC")
names(new.cluster.ids_2) <- levels(P33)
P33 <- RenameIdents(P33, new.cluster.ids_2)

#
table(Idents(P33))
#prop.table(table(Idents(P33)))
cell.prop_P33<-as.data.frame(prop.table(table(Idents(P33))))
#cell.prop_P33<-as.data.frame(table(Idents(P33)))
colnames(cell.prop_P33)<-c("cell_type","proportion")
cell.prop_P33$time<-"P33"
signif(cell.prop_P33$proportion, 4)

ggplot(cell.prop_P33,aes(cell_type,proportion,fill=cell_type))+geom_bar(stat="identity",position = position_dodge(1))+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_igv()+
  geom_text(aes(label=signif(proportion, 4), y=proportion+0.005), position=position_dodge(1), vjust=0)


######### merge
setwd("C:\\Users\\zhaoyf\\OneDrive - st.shou.edu.cn\\桌面\\repeat2 mouse\\select_SC_HC-edger\\cell propotion_only_sc_hc")
merge<- rbind(cell.prop_E14,cell.prop_E16,cell.prop_P1,cell.prop_P7,cell.prop_P12,cell.prop_P33)
merge$time<-factor(merge$time,levels=c("E_14","E_16","P1","P7","P12","P33"),ordered=TRUE)
ggplot(merge,aes(time,proportion,fill=cell_type))+geom_bar(stat='identity',position='stack')+theme_classic()+
  ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_manual(values=c("#478bA2","#DDC1C6","#F2A490","#E9765B"))

merge_r1 <- data.frame(cell_type=NA,proportion=NA,time=NA)
merge_r1<- merge_r1[-1,]
for(i in 1:length(unique(merge$cell_type))){
  merge_w <- merge[merge$cell_type%in%unique(merge$cell_type)[i],]
  merge_r2 <- data.frame(cell_type=NA,proportion=NA,time=NA)
  merge_r2<- merge_r2[-1,]
  for (j in 1:length(unique(merge_w$time))){
    merge_w2<- merge_w[merge_w$time%in%merge_w$time[j],]
    merge_w3<-data.frame("other cell type",(1-merge_w2$proportion),merge_w2$time)
    colnames(merge_w3)<-c(colnames(merge_w2))
    merge_w4 <- rbind(merge_w2,merge_w3)
    merge_r2<- rbind(merge_r2,merge_w4)
}
  merge_r1<- rbind(merge_r1,merge_r2)
  p<-ggplot(merge_r2,aes(time,proportion,fill=cell_type))+geom_bar(stat='identity',position='stack')+
    ggtitle("")+theme_bw()+theme(axis.ticks.length=unit(0.5,'cm'))+scale_fill_manual(values=c("#003399","#9999CC"))
  file_name<-paste("proportion_",merge$cell_type[i],".pdf",sep = "")
  ggsave(p,file=file_name,width = 5,height = 4,device = "pdf")

}

p

